/**
  ******************************************************************************
  * File Name          : freertos.c
  * Description        : Code for freertos applications
  ******************************************************************************
  * This notice applies to any and all portions of this file
  * that are not between comment pairs USER CODE BEGIN and
  * USER CODE END. Other portions of this file, whether
  * inserted by the user or by software development tools
  * are owned by their respective copyright owners.
  *
  * Copyright (c) 2018 STMicroelectronics International N.V.
  * All rights reserved.
  *
  * Redistribution and use in source and binary forms, with or without
  * modification, are permitted, provided that the following conditions are met:
  *
  * 1. Redistribution of source code must retain the above copyright notice,
  *    this list of conditions and the following disclaimer.
  * 2. Redistributions in binary form must reproduce the above copyright notice,
  *    this list of conditions and the following disclaimer in the documentation
  *    and/or other materials provided with the distribution.
  * 3. Neither the name of STMicroelectronics nor the names of other
  *    contributors to this software may be used to endorse or promote products
  *    derived from this software without specific written permission.
  * 4. This software, including modifications and/or derivative works of this
  *    software, must execute solely and exclusively on microcontroller or
  *    microprocessor devices manufactured by or for STMicroelectronics.
  * 5. Redistribution and use of this software other than as permitted under
  *    this license is void and will automatically terminate your rights under
  *    this license.
  *
  * THIS SOFTWARE IS PROVIDED BY STMICROELECTRONICS AND CONTRIBUTORS "AS IS"
  * AND ANY EXPRESS, IMPLIED OR STATUTORY WARRANTIES, INCLUDING, BUT NOT
  * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
  * PARTICULAR PURPOSE AND NON-INFRINGEMENT OF THIRD PARTY INTELLECTUAL PROPERTY
  * RIGHTS ARE DISCLAIMED TO THE FULLEST EXTENT PERMITTED BY LAW. IN NO EVENT
  * SHALL STMICROELECTRONICS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
  * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA,
  * OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
  * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
  * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
  * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "FreeRTOS.h"
#include "task.h"
#include "cmsis_os.h"

/* USER CODE BEGIN Includes */
#include "stdio.h"
#include "usart.h"
#include "string.h"
#include "hal_iic_oled.h"

unsigned char a = 10;
unsigned char b = 0;

#define IO_Control_Relay(x,y)  IO_Control_##x(y)
#define IO_Control_1(y)    (a = y)
#define IO_Control_2(y)    (a = y + 1)

/* USER CODE END Includes */

/* Variables -----------------------------------------------------------------*/
osThreadId defaultTaskHandle;

/* USER CODE BEGIN Variables */
osThreadId lpUart1ScanTaskHandle;
xSemaphoreHandle xScanSemaphore;

extern uint8_t ReceiveBuff[RXBUFFERSIZE];
extern uint8_t ReceiveInfo[RXBUFFERSIZE];
extern uint8_t Rx_BufferLen;
extern uint8_t Rx_InfoLen;
/* USER CODE END Variables */

/* Function prototypes -------------------------------------------------------*/
void StartDefaultTask(void const * argument);

void MX_FREERTOS_Init(void); /* (MISRA C 2004 rule 8.1) */

/* USER CODE BEGIN FunctionPrototypes */
void StartlpUart1ScanTask(void const * argument);

/* USER CODE END FunctionPrototypes */

/* Hook prototypes */

/* Init FreeRTOS */

void MX_FREERTOS_Init(void) {
    /* USER CODE BEGIN Init */

    /* USER CODE END Init */

    /* USER CODE BEGIN RTOS_MUTEX */
    /* add mutexes, ... */
    /* USER CODE END RTOS_MUTEX */

    /* USER CODE BEGIN RTOS_SEMAPHORES */
    /* add semaphores, ... */
    xScanSemaphore = xSemaphoreCreateBinary();
    /* USER CODE END RTOS_SEMAPHORES */

    /* USER CODE BEGIN RTOS_TIMERS */
    /* start timers, add new ones, ... */
    /* USER CODE END RTOS_TIMERS */

    /* Create the thread(s) */
    /* definition and creation of defaultTask */
    osThreadDef(defaultTask, StartDefaultTask, osPriorityNormal, 0, 128);
    defaultTaskHandle = osThreadCreate(osThread(defaultTask), NULL);

    /* USER CODE BEGIN RTOS_THREADS */
    /* add threads, ... */
    osThreadDef(usartTask, StartlpUart1ScanTask, osPriorityHigh, 0, 128);
    lpUart1ScanTaskHandle = osThreadCreate(osThread(usartTask), NULL);
    /* USER CODE END RTOS_THREADS */

    /* USER CODE BEGIN RTOS_QUEUES */
    /* add queues, ... */
    /* USER CODE END RTOS_QUEUES */
}

/* StartDefaultTask function */
void StartDefaultTask(void const * argument)
{

    /* USER CODE BEGIN StartDefaultTask */
    /* Infinite loop */
    for(;;)
    {
        osDelay(500);
    }
    /* USER CODE END StartDefaultTask */
}

/* USER CODE BEGIN Application */
void StartlpUart1ScanTask(void const * argument)
{
		uint32_t  Voltage_Parameter_REG = 0, Voltage_REG = 0 ;
		uint32_t  Current_Parameter_REG = 0, Current_REG = 0 ;
		uint32_t  Power_Parameter_REG = 0  , Power_REG = 0   ;
		uint32_t  State7_REG = 0, State7_REG_1 = 0, PF_REG = 0 , k = 0  , num = 1462309; ;
		float KW_H = 0 ;
		unsigned long   PF_Cut = 0  ;
		float Voltage_Data = 0 , Current_Data = 0 , Power_Data = 0 ;
		float Apparent_Power_Data= 0 , Power_factor = 0 ;
    configASSERT(xScanSemaphore);
    xSemaphoreTake(xScanSemaphore,0);
    for(;;)
    {
        xSemaphoreTake(xScanSemaphore,portMAX_DELAY);
        HAL_UART_Transmit(&huart3,ReceiveInfo,Rx_InfoLen,0x0F);
        if(0 != Rx_InfoLen)
        {
            Voltage_Parameter_REG = (ReceiveInfo[2]<<16) + (ReceiveInfo[3]<<8) + ReceiveInfo[4];
            Voltage_REG = (ReceiveInfo[5]<<16) + (ReceiveInfo[6]<<8) + ReceiveInfo[7];
            Voltage_Data =((float) Voltage_Parameter_REG )/((float) Voltage_REG )*1.88;

            Current_Parameter_REG = (ReceiveInfo[8]<<16) + (ReceiveInfo[9]<<8) + ReceiveInfo[10];
            Current_REG = (ReceiveInfo[11]<<16) + (ReceiveInfo[12]<<8) + ReceiveInfo[13];
            Current_Data = ((float) Current_Parameter_REG )/((float) Current_REG )/1.0;

						Power_Parameter_REG = (ReceiveInfo[14]<<16) + (ReceiveInfo[15]<<8) + ReceiveInfo[16];
            Power_REG = (ReceiveInfo[17]<<16) + (ReceiveInfo[18]<<8) + ReceiveInfo[19];
            Power_Data = ((float) Power_Parameter_REG )/((float) Power_REG )*1.88/1.0;

            State7_REG = ReceiveInfo[0] >> 7 ;                
            PF_REG = (ReceiveInfo[21]<<8) + ReceiveInfo[22] ;
            if( State7_REG != State7_REG_1 )
						{	
								State7_REG_1 = State7_REG ;
								k++;
						}
						PF_Cut = k * 65536 + PF_REG ;	
						KW_H = 1.0 * PF_Cut / num ;
						Apparent_Power_Data= Voltage_Data * Current_Data ;
						Power_factor = Power_Data / Apparent_Power_Data;

						printf("\r\n");
            printf("V=%f\r\n", Voltage_Data );
            printf("I=%f\r\n", Current_Data );
            printf("P=%f\r\n", Power_Data );

            printf("S=%f\r\n", Apparent_Power_Data);
            printf("cos=%f\r\n", Power_factor );


            OLED_ShowFloat(4*6,2, Voltage_Data,1);

            OLED_ShowFloat(4*6,3, Current_Data,1);

            OLED_ShowFloat(4*6,4, Power_Data,1);

            OLED_ShowFloat(4*6,5, Apparent_Power_Data,1);

            OLED_ShowFloat(4*6,6, Power_factor,1);
			
            OLED_ShowFloat(6*6,7, KW_H ,1);
        }
        memset(ReceiveInfo,0x00,Rx_InfoLen);
        Rx_InfoLen = 0;
    }
}
/* USER CODE END Application */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
